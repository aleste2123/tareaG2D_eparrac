/**
 * 
 */
/**
 * @author Gatoloco
 *
 */
module Java2D {
	requires java.desktop;
}